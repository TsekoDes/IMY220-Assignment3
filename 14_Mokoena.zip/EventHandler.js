function EventHandler(arr)
{
    this.getEventsBetweenDates = function(start, end)
    {
        var newArr;
        newArr = arr.filter(function(element)
        {
            if(element["dateStart"] >= start && element["dateEnd"] <= end)
                return element;
        });
        return newArr;
    }
    this.getByMonth = function(month)
    {
        var strMonth = month.toString();
        if(strMonth.length == 1)
        {
            var newStr = "0"+strMonth;
        }
        var newArr2 = arr.filter(function(element)
        {
            var myStr = element["dateStart"].slice(5,7);
            var conv = myStr.toString();
            if(myStr == newStr)
            {
                return element;
            }
        });
        return newArr2;
    }

    this.getUniqueDateAndSort = function()
    {
        var anotherA = arr;
        var temp = anotherA.sort((el1, el2) => {
            if(el1.dateStart < el2.dateStart)
                return -1;
            else if(el1.dateStart > el2.dateStart)
                return 1;
            else return 0;
        });
        var finArr2 = new Set(); 
        var finArr1 = temp.filter(arrEl=>{
            var sameVal1 = finArr2.has(arrEl.dateStart);
            var sameVal2 = finArr2.has(arrEl.dateEnd);
            finArr2.add(arrEl.dateStart);
            if(!sameVal1 && !sameVal2)
                return true;
            else
                return false;
        });
        return finArr1;
    }
    this.getSummary = function(...args)
    {
        var out = "";
        if(args[0] != undefined)
        {
            for(var a = 0; a<arr.length; a++)
            {
                if(args[a].dateStart == args[a].dateEnd)
                {
                    out += "On "+args[a].dateStart+": "+args[a].name+" ("+args[a].description+")\n";
                }
                else
                {
                    out += "From "+args[a].dateStart+" to "+args[a].dateEnd+": "+args[a].name+" ("+args[a].description+")\n";
                }
            }
        }
        else
        {
            for(var a = 0; a<arr.length; a++)
            {
                if(arr[a].dateStart == arr[a].dateEnd)
                {
                    out += "On "+arr[a].dateStart+": "+arr[a].name+" ("+arr[a].description+")\n";
                }
                else
                {
                    out += "From "+arr[a].dateStart+" to "+arr[a].dateEnd+": "+arr[a].name+" ("+arr[a].description+")\n";
                }
            }
        }
        return out;
    }
}

//var callFunc = new EventHandler(events);
//console.log(callFunc.getEventsBetweenDates("2022/04/01", "2022/06/12"));
//console.log(callFunc.getByMonth(06));
//console.log(callFunc.getUniqueDateAndSort());
//console.log(callFunc.getSummary());
